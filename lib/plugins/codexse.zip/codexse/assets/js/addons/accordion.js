;(function ($) {
    var accordion_addons = function ($scope, $) {
        var accordion_list = $scope.find('.accordion-list').eq(0);
        if (accordion_list.length > 0) {
            accordion_list.each(function () {
                $(this).find('.accoridon-item .title').on('click', function () {
                    $(this).parent('.accoridon-item').siblings('.accoridon-item').find('.desc').slideUp();
                    $(this).parent('.accoridon-item').siblings('.accoridon-item').find('.title').removeClass('active');
                    $(this).siblings('.desc').slideToggle();
                    $(this).toggleClass('active');
                });
            });
        }
    }
    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-accordion-addons.default', accordion_addons);
    });
}(jQuery));