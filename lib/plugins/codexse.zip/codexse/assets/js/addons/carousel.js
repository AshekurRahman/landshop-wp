;
(function ($) {

    var testimonial_section_1 = function ($scope, $) {
        var slider_elem = $scope.find('.testimonial_slider_1').eq(0);
        /*====== Testimonial-Slider ======*/
        var Slider_Navigation = new Swiper(slider_elem.find(".testimonial-navigate-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 30,
            slidesPerView: 2,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            breakpoints: {
                320: {
                    slidesPerView: 2,
                },
                520: {
                    slidesPerView: 3,
                },
            },
        });
        var Slider_Photo = new Swiper(slider_elem.find(".testimonial-photo-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 0,
            slidesPerView: 1,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            navigation: {
                nextEl: ".testimonial-navigation .next",
                prevEl: ".testimonial-navigation .prev",
            },
            thumbs: {
                swiper: Slider_Navigation,
            },
        });
        var Slider_Content = new Swiper(slider_elem.find(".testimonial-content-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 30,
            slidesPerView: 1,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            thumbs: {
                swiper: Slider_Navigation,
            },
        });

        Slider_Photo.controller.control = Slider_Navigation;
        Slider_Photo.controller.control = Slider_Content;
        Slider_Content.controller.control = Slider_Navigation;
        Slider_Content.controller.control = Slider_Photo;
    }

    var carousel_controler = function ($scope, $) {
        var slider_elem = $scope.find('.swiper-container').eq(0);
        if (slider_elem.length > 0) {
            settings = slider_elem.data('settings');
            var slpaginate = settings['slpaginate'] ? {
                el: $scope.find('.swiper-pagination'),
                clickable: true,
                type: 'bullets',
                renderBullet: function (i) {
                    return `<span class="dot swiper-pagination-bullet" ><svg><circle style="animation-duration: ${slautolaydelay / 1000}s;" cx="11" cy="11" r="10"></circle></svg></span>`;
                }
            } : false;

            var slloop = settings['slloop'];
            var sleffect = settings['sleffect'];
            var slautolaydelay = settings['slautolaydelay'];
            var slanimation_speed = settings['slanimation_speed'];
            var coverflow_rotate = settings['coverflow_rotate'] ? parseInt(settings['coverflow_rotate']) : 0;
            var coverflow_stretch = settings['coverflow_stretch'] ? parseInt(settings['coverflow_stretch']) : 0;
            var coverflow_depth = settings['coverflow_depth'] ? parseInt(settings['coverflow_depth']) : 0;
            var coverflow_shadow = settings['coverflow_shadow'] == 'yes' ? true : false;
            var slcustom_arrow = settings['slcustom_arrow'];
            var slider_target_id = settings['sltarget_id'];
            var sldisplay_columns = parseInt(settings['sldisplay_columns']);
            var slcenter = settings['slcenter'];
            var sldirection = settings['sldirection'] ? settings['sldirection'] : 'horizontal';
            var slcenter_padding = parseInt(settings['slcenter_padding']);

            var laptop_width = parseInt(settings['laptop_width']);
            var tablet_width = parseInt(settings['tablet_width']);
            var mobile_width = parseInt(settings['mobile_width']);
            var laptop_padding = parseInt(settings['laptop_padding']);
            var tablet_padding = parseInt(settings['tablet_padding']);
            var mobile_padding = parseInt(settings['mobile_padding']);
            var laptop_display_columns = parseInt(settings['laptop_display_columns']);
            var tablet_display_columns = parseInt(settings['tablet_display_columns']);
            var mobile_display_columns = parseInt(settings['mobile_display_columns']);

            var swiperOptions = {
                loop: slloop,
                speed: slanimation_speed,
                centeredSlides: slcenter,
                slidesPerView: sldisplay_columns,
                spaceBetween: slcenter_padding,
                direction: sldirection,
                effect: sleffect, // More Options: 'slide' | 'fade' | 'cube' | 'coverflow' | 'flip' 

                coverflowEffect: {
                    rotate: coverflow_rotate,
                    stretch: coverflow_stretch,
                    depth: coverflow_depth,
                    modifier: 1,
                    slideShadows: coverflow_shadow,
                },

                autoplay: {
                    delay: slautolaydelay,
                    disableOnInteraction: false
                },
                navigation: {
                    prevEl: (slcustom_arrow == true && slider_target_id != null ? '#slider-arrow-' + slider_target_id + ' .prev-action' : $scope.find('.swiper-navigation .swiper-prev')),
                    nextEl: (slcustom_arrow == true && slider_target_id != null ? '#slider-arrow-' + slider_target_id + ' .next-action' : $scope.find('.swiper-navigation .swiper-next')),
                },
                pagination: slpaginate,
                breakpoints: {
                    [mobile_width]: {
                        slidesPerView: mobile_display_columns,
                        spaceBetween: mobile_padding,
                    },
                    [tablet_width]: {
                        slidesPerView: tablet_display_columns,
                        spaceBetween: tablet_padding,
                    },
                    [laptop_width]: {
                        slidesPerView: laptop_display_columns,
                        spaceBetween: laptop_padding,
                    },
                },
            };
            var swiper = new Swiper(slider_elem, swiperOptions);
        }
    }
    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-carousel-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-portfolio-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-news-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-testimonial-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-testimonial-section-1.default', testimonial_section_1);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-product-addons.default', carousel_controler);
    });
}(jQuery));