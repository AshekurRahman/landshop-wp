<?php

namespace Codexse\PostType;

class Portfolio
{
    public function __construct() {
        add_action( 'init', array( $this, 'codexse_register_portfolio_post_type' ) );
    }
  
    public function codexse_register_portfolio_post_type() {
        $labels = array(
            'name'               => __('Portfolio', 'codexse'),
            'singular_name'      => __('Portfolio', 'codexse'),
            'add_new'            => __('Add New', 'codexse'),
            'add_new_item'       => __('Add New Portfolio Item', 'codexse'),
            'edit_item'          => __('Edit Portfolio Item', 'codexse'),
            'new_item'           => __('New Portfolio Item', 'codexse'),
            'view_item'          => __('View Portfolio Item', 'codexse'),
            'search_items'       => __('Search Portfolio Items', 'codexse'),
            'not_found'          => __('No portfolio items found', 'codexse'),
            'not_found_in_trash' => __('No portfolio items found in trash', 'codexse'),
            'parent_item_colon'  => '',
            'menu_name'          => __('Portfolio', 'codexse')
        );

        $args = array(
            'labels'              => $labels,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'query_var'           => true,
            'rewrite'             => array( 'slug' => 'portfolio' ),
            'capability_type'     => 'post',
            'has_archive'         => true,
            'hierarchical'        => false,
            'menu_position'       => null,
            'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments', 'revisions' ),
            'taxonomies'          => array( 'category', 'post_tag' )
        );

        register_post_type( 'portfolio', $args );
    }
}