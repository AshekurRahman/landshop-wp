<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Testimonial_1 extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-testimonial-section-1';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Testimonial 1', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-img testimonial_1';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories(){
        return ["codexse-section"];
    }                                                                                                                                                             
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',
            'codexse-testimonial'                                                                                                               
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {                                                                                                                        
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'testimonial_content',                                                                                                                                      
            [                                                                                                                                                       
                'label' => __( 'Testimonial', 'codexse' ),                                                                                                      
            ]                                                                                                                                                       
        );                                                                                                                         
            $this->add_control(                                                                                                                                 
                'section_title',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Section Title', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type section title.','codexse'),                                                                                        
                    'default' => __('Reviews From Our Clients','codexse'),
                ]                                                                                                                                                   
            );                                                                                                                                     
                                                                                                                                                                    
            $repeater = new Repeater();           
            
            $repeater->add_control(                                                                                                                                 
                'testimonial_description',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Description', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXTAREA,                                                                                                            
                    'placeholder' => __('Enter type your client feedback massage.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                       
            $repeater->add_control(                                                                                                                                 
                'testimonial_name',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Name', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client name.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                       
            $repeater->add_control(                                                                                                                                 
                'testimonial_position',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Position', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client position.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $repeater->add_control(                                                                                                                                 
                'testimonial_image',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => __( 'Image', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::MEDIA,                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $repeater->add_group_control(                                                                                                                           
                Group_Control_Image_Size::get_type(),                                                                                                               
                [                                                                                                                                                   
                    'name' => 'testimonial_imagesize',                                                                                                                  
                    'default' => 'large',                                                                                                                           
                    'separator' => 'none',                                                                                                                          
                ]                                                                                                                                                   
            );  
            
            $repeater->add_control(
                "rating_switch", 
                [
                    "label" => __("Show rating star", "codexse"),
                    "type" => Controls_Manager::SWITCHER,
                    "default" => "no",
                    "label_on" => __("Show", "codexse"),
                    "label_off" => __("Hide", "codexse"),
                ]
            );

            $repeater->add_control(
                "rating", 
                [
                    "label" => __("Rating", "codexse"),
                    "type" => Controls_Manager::SLIDER,
                    "default" => ["size" => 3],
                    "range" => ["px" => ["max" => 5, "step" => 0.1]],
                    "condition" => ["rating_switch" => "yes"],
                ]
            );                                                                                                                                                       
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'testimonial_list',                                                                                                                               
                [                                                                                                                                                   
                    'type'    => Controls_Manager::REPEATER,                                                                                                        
                    'fields'  => $repeater->get_controls(),                                                                                                         
                    'default' => [                                                                                                                                  
                                                                                                                                                                    
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Helena Paitora','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Jason Kink','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Irfan Raza','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                                          
                                                                                                                                                                    
                    ],                                                                                                                                              
                    'title_field' => '{{{ testimonial_name }}}',                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                         
                                                                                                                                                               
        $this->end_controls_section(); 
        
                
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __( 'Section Title', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_title_typo',
                'selector' => '{{WRAPPER}} .testimonial_slider_1 .section-title .title',
            ]
        );
        $this->add_control(
            'section_title_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_1 .section-title .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'section_title_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_1 .section-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'section_title_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_1 .section-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->end_controls_section();
         
                                                                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {                                                                                   
        $settings   = $this->get_settings_for_display(); ?>
        <!-- Testimonial-Area-Start -->
        <section class="testimonial_slider_1">
            <div class="container-fluid elementor-container">
                <div class="row align-items-center">
                    <div class="col-lg-5 d-none d-lg-block position-relative">
                        <div class="testimonial-photo-slide swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                    <div class="swiper-slide">
                                        <figure class="single-image">
                                            <?php           
                                                if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' )){
                                                    echo '<div class="thumbnail">';
                                                        echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' );
                                                    echo '</div>';
                                                }
                                            ?>
                                        </figure>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="slider-controls testimonial-navigation">
                            <button type="button" class="control next"><i class="fa-regular fa-angle-left"></i></button>
                            <button type="button" class="control prev"><i class="fa-regular fa-angle-right"></i></button>
                        </div>
                    </div>
                    <div class="col-lg-6 offset-lg-1">
                        <?php if(!empty($settings['section_title'])): ?>
                            <div class="section-title">
                                <h2 class="title"><?php echo esc_html($settings['section_title']); ?></h2>
                            </div>
                        <?php endif; ?>
                        <div class="testimonial-content-slide  swiper-container">
                            <div class="swiper-wrapper">
                            <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                <div class="swiper-slide">
                                    <div class="testimonial-box">
                                        <div class="testimonial-header">
                                            <div class="quote"></div>
                                            <?php
                                                if ($item["rating_switch"] == "yes"):
                                                    echo '<div class="feed-rating">';
                                                        echo '<span class="star front"></span>';
                                                        echo '<span class="star back" style="width: '. esc_attr( $item["rating"]["size"] * 20 ) .'%"></span>';
                                                    echo '</div>';
                                                endif;
                                            ?>
                                        </div>
                                        <div class="testimonial-body">
                                            <?php
                                                if( !empty($item['testimonial_description']) ){
                                                    echo '<div class="description">';
                                                        echo esc_html($item['testimonial_description']);
                                                    echo '</div>';
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="testimonial-navigate-slide  swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                    <div class="swiper-slide">
                                        <?php     
                                            if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' )){
                                                echo '<div class="thumbnail">';
                                                echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' );
                                                echo '</div>';
                                            }
                                        ?>
                                        <?php
                                            echo '<div class="testimonial-info">';
                                                if( !empty($item['testimonial_name']) ){
                                                echo '<h3 class="title">'.esc_html($item['testimonial_name']).'</h3>';
                                                }                      
                                                if( !empty($item['testimonial_position']) ){
                                                echo '<div class="position">'.esc_html($item['testimonial_position']).'</div>';
                                                }
                                            echo '</div>';
                                        ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonial-Area-End -->
        <?php                                                                                                                                                
    }     
    
    
    public function on_add_to_editor() {
        // Override the default behavior when added to the editor
        $this->add_wrapper_attributes();
    }

    protected function add_wrapper_attributes() {
        // You can add wrapper attributes here if needed
    }

    public function get_render_wrapper_attributes() {
        // Return an empty string to prevent the default wrapper
        return '';
    }

    public function get_render_inner_wrapper_attributes() {
        // Return an empty string to prevent the default inner wrapper
        return '';
    }
                                                                                                                                                                    
}                                                                                                                                                                   
                                                                                                                                                                    
