<?php

namespace Codexse\Widgets;
use WP_Widget;
use WP_Query;


class ElementorTemplate extends WP_Widget
{
    function __construct(){
        parent::__construct(
            'elementor_template_widget', 
            esc_html__('Elementor Widget', 'codexse'),
            array( 'description' => esc_html__( 'Kindly choose an Elementor template, and it will be displayed in your widget.', 'codexse' ) )
        );
    }
    
    public function widget( $args, $instance ){
        $elementor_template = isset($instance['elementor_template']) ? $instance['elementor_template'] : 'none' ;
        echo $args['before_widget']; 
        if( !empty($instance['title']) ){
            echo $args['before_title'] . $instance['title'] . $args['after_title'];
        }
        $posts = new WP_Query(array(
            'post_type' => 'elementor_library',
            'posts_per_page'=> -1,
            'p' => $elementor_template,
        ));
            
        if( $posts->have_posts() ):
            while( $posts->have_posts() ):
                $posts->the_post();                   
                the_content();          
            endwhile;
            wp_reset_postdata(); // Reset post data to the original query
        endif;
        echo $args['after_widget'];
    }
    

    public function form($instance) {
        // Form fields for the widget in the admin
        $title = (isset($instance['title']) ? $instance['title'] : '');
        $elementor_template = (isset($instance['elementor_template']) ? $instance['elementor_template'] : '');
        // Assuming $templates is the output of landshop_get_post_title('elementor_library')
        $templates = landshop_get_post_title('elementor_library');
        echo '<p>';
        echo '<label for="' . esc_attr($this->get_field_id('title')) . '">';
        esc_html_e('Title:', 'codexse');
        echo '</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '" />';
        echo '</p>';
        echo '<p>';
        echo '<label for="' . esc_attr($this->get_field_id('elementor_template')) . '">';
        esc_html_e('Select an Elementor template:', 'codexse');
        echo '</label>';
        if (empty($templates)) {
            $create_template_link = admin_url('post-new.php?post_type=elementor_library');
            echo '<span class="error-message">';
            printf(
                esc_html__('Your template is empty. Please <a href="%s">create an Elementor template</a>.', 'codexse'),
                esc_url($create_template_link)
            );
            echo '</span>';
        } else {
            echo '<select class="tiny-text" id="' . esc_attr($this->get_field_id('elementor_template')) . '" name="' . esc_attr($this->get_field_name('elementor_template')) . '" value="' . esc_attr($elementor_template) . '">';
            echo '<option value="none">' . esc_html__('None', 'codexse') . '</option>';
            foreach ($templates as $template_id => $template_title) {
                echo '<option value="' . esc_attr($template_id) . '" ' . selected($elementor_template, $template_id, false) . '>' . esc_html($template_title) . '</option>';
            }
            echo '</select>';
        }
        echo '</p>';
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['elementor_template'] = ! empty( $new_instance['elementor_template'] ) ? intval( $new_instance['elementor_template'] ) : 'none';
        return $instance;
    }
    
}
