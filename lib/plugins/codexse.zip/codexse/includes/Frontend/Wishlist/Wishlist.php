<?php

namespace Codexse\Frontend\Wishlist;

class Wishlist
{
    public function __construct()
    {
        // Hook the wishlist button to product items
        // add_action('woocommerce_after_shop_loop_item', array($this, 'add_wishlist_button'), 5);
        // Add the wishlist button HTML to the single product page
        // add_action('woocommerce_single_product_summary', array($this, 'add_wishlist_button'), 40);

        
        // Callback function to add a product to the wishlist
        add_action('wp_ajax_add_to_wishlist', array($this, 'add_to_wishlist'));
        add_action('wp_ajax_nopriv_add_to_wishlist', array($this, 'add_to_wishlist')); // For non-logged-in users
        // Callback function to remove a product from the wishlist
        add_action('wp_ajax_remove_from_wishlist', array($this, 'remove_from_wishlist'));
        add_action('wp_ajax_nopriv_remove_from_wishlist', array($this, 'remove_from_wishlist')); // For non-logged-in users
        // Display User's Wishlist
        add_shortcode('display_wishlist', array($this, 'wishlist_shortcode'));
        // Create Wishlist Page
        add_action('init', array($this, 'create_wishlist_page'));
    }
    
    // Create a Wishlist Page
    public function create_wishlist_page()
    {
        $page_title = 'Wishlist'; // Set the title of the wishlist page
        $page_content = '[display_wishlist]'; // Shortcode to display the wishlist items
        $page_check = get_page_by_title($page_title);

        // Create the wishlist page if it doesn't exist
        if (empty($page_check)) {
            $page = array(
                'post_type' => 'page',
                'post_title' => $page_title,
                'post_content' => $page_content,
                'post_status' => 'publish',
                'post_author' => 1, // You can set the author as needed
            );

            wp_insert_post($page);
        }
    }

    // Callback function to add a product to the wishlist
    public function add_to_wishlist()
    {
        $product_id = $_POST['product_id'];
        $user_id = get_current_user_id();

        if ($user_id) {
            $wishlist =  get_user_meta($user_id, 'wishlist', true) ? get_user_meta($user_id, 'wishlist', true) : [];
            if (!$wishlist) {
                $wishlist = array();
            }

            // Check if the product is not already in the wishlist
            if (!in_array($product_id, $wishlist)) {
                $wishlist[] = $product_id;
                update_user_meta($user_id, 'wishlist', $wishlist);
                echo 'Product added to wishlist!';
            } else {
                echo 'Product is already in the wishlist!';
            }
        } else {
            echo 'You must be logged in to add products to the wishlist.';
        }

        wp_die();
    }

    // Callback function to remove a product from the wishlist
    public function remove_from_wishlist()
    {
        $product_id = $_POST['product_id'];
        $user_id = get_current_user_id();

        if ($user_id) {
            $wishlist = get_user_meta($user_id, 'wishlist', true) ? get_user_meta($user_id, 'wishlist', true) : [];

            if ($wishlist && in_array($product_id, $wishlist)) {
                // Remove the product from the wishlist
                $updated_wishlist = array_diff($wishlist, array($product_id));
                update_user_meta($user_id, 'wishlist', $updated_wishlist);
                echo 'success';
            } else {
                echo 'error'; // Product not found in the wishlist
            }
        } else {
            echo 'error'; // User not logged in
        }

        wp_die();
    }

    // Add the wishlist button HTML to the single product page
    public function add_wishlist_button()
    {

        // Check if WooCommerce is active
        if (class_exists('WooCommerce')) {
            // Get the product ID
            $product_id = get_the_ID();
            $user_id = get_current_user_id();
            
            // Check if the user is logged in
            if ($user_id) {
                // Get the user's wishlist
                $wishlist = get_user_meta($user_id, 'wishlist', true) ? get_user_meta($user_id, 'wishlist', true) : [];

                // Check if the product is in the wishlist
                $is_in_wishlist = in_array($product_id, $wishlist);

                // Output the wishlist button with or without the active class
                echo '<button type="button" class="button wishlist-button outline' . ($is_in_wishlist ? ' added' : '') . '" data-product-id="' . $product_id . '"><i class="fa-regular fa-heart ms-0"></i></button>';
            } else {
                // If user is not logged in, just output the button without the active class
                echo '<button type="button" class="button wishlist-button outline" data-product-id="' . $product_id . '"><i class="fa-regular fa-heart ms-0"></i></button>';
            }
        }
    }

    // Display User's Wishlist
    public function display_wishlist()
    {
        $user_id = get_current_user_id();
        if ($user_id) {
            $wishlist = get_user_meta($user_id, 'wishlist', true);
            if ($wishlist) {
                echo '<div class="row g-4" >';
                foreach ($wishlist as $product_id) {
                    $product = wc_get_product($product_id);
                    if ($product) {
                        $price_html = $product->get_price_html();
                        $price_html = str_replace('bdi', 'span', $price_html);
                        $price_html = str_replace('&nbsp;', '', $price_html);
                        echo '<div class="col-lg-6 cart__product_item">';
                            echo '<div class="cart__product">';
                            echo '<div class="product-remove">';
                                echo '<button type="button" class="close-item remove-from-wishlist remove" data-product-id="' . $product_id . '"><i class="fa-regular fa-times"></i></button>';
                            echo '</div>';
                            echo '<figure class="product__image">';
                            echo $product->get_image();
                            echo '</figure>';
                            echo '<div class="product__details">';
                                echo '<h5 class="product__title mb-1">'. $product->get_title() .'</h5>';
                                echo '<div class="product__info">';
                                if($price_html):
                                echo '<div class="product__price">';
                                    echo '<strong>'.__('Price','codexse').': </strong>';
                                    echo $price_html;
                                echo '</div>';
                                endif;
                                if($product->get_stock_status()):
                                echo '<div class="product__price">';
                                echo '<strong>'.__('Status','codexse').': </strong>';
                                    echo $product->get_stock_status();
                                echo '</div>';
                                endif;
                                echo '</div>';
                                echo do_shortcode('[add_to_cart id="' . $product_id . '" show_price="false" style=""]');
                            echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    }
                }
                echo '</div>';
            } else {
               echo '<div class="woocommerce-info">'. __('Your wishlist is empty.','codexse').'</div>';
            }
        } else {
            echo '<div class="woocommerce-info">'. __('You must be logged in to view your wishlist.','codexse').' <a href="'.esc_url( home_url('/my-account') ).'" class="link">'.__('Login Or Register Now','codexse').'</a>'.'</div>';

            var_dump();
        }
    }
    

    // Add a Shortcode for Displaying Wishlist
    public function wishlist_shortcode()
    {
        ob_start();
        $this->display_wishlist();
        return ob_get_clean();
    }
}
