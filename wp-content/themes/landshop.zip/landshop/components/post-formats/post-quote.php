<div <?php post_class( ['quote_post post-box'] ); ?> >
    <div class="content">
        <blockquote>
            <?php the_content(); ?>
		</blockquote>
    </div>
</div>