<div <?php post_class( ['link_post post-box'] ); ?> >
    <div class="content">
        <blockquote>
            <?php the_content(); ?>
		</blockquote>
    </div>
</div>