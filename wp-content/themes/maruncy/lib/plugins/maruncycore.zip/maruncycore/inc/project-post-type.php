<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Project: Custom Post Types
 *
 *
 */
class maruncycore_project_Post_Types {
	
	public function __construct()
	{
		$this->register_post_type();
	}

	public function register_post_type()
	{
		$args = array();	

		// project
		$args['project-type'] = array(
			'labels' => array(
				'name' => __( 'Projects', 'maruncycore' ),
				'singular_name' => __( 'Project', 'maruncycore' ),
				'add_new' => __( 'Add project', 'maruncycore' ),
				'add_new_item' => __( 'Add project', 'maruncycore' ),
				'edit_item' => __( 'Edit project', 'maruncycore' ),
				'new_item' => __( 'New project', 'maruncycore' ),
				'view_item' => __( 'View project', 'maruncycore' ),
				'search_items' => __( 'Search Through project', 'maruncycore' ),
				'not_found' => __( 'No project found', 'maruncycore' ),
				'not_found_in_trash' => __( 'No project found in Trash', 'maruncycore' ),
				'parent_item_colon' => __( 'Parent project:', 'maruncycore' ),
				'menu_name' => __( 'Projects', 'maruncycore' ),				
			),		  
			'hierarchical' => false,
	        'description' => __( 'Add a project item', 'maruncycore' ),
	        'supports' => array( 'title', 'editor', 'thumbnail'),
	        'menu_icon' =>  'dashicons-analytics',
	        'public' => true,
	        'publicly_queryable' => true,
	        'exclude_from_search' => false,
	        'query_var' => true,
	        'rewrite' => array( 'slug' => 'project' ),
	        // This is where we add taxonomies to our CPT
        	'taxonomies'          => array( 'project_category' ),
		);	

		// Register post type: name, arguments
		register_post_type('project', $args['project-type']);
	}
}

function maruncycore_project_types() { new maruncycore_project_Post_Types(); }

add_action( 'init', 'maruncycore_project_types' );

/*-----------------------------------------------------------------------------------*/
/*	Creating Custom Category 
/*-----------------------------------------------------------------------------------*/
// hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'maruncycore_create_project_category', 0 );

// create two category, genres and writers for the post type "book"
function maruncycore_create_project_category() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Categories', 'taxonomy general name', 'maruncycore' ),
		'singular_name'     => _x( 'Category', 'taxonomy singular name', 'maruncycore' ),
		'search_items'      => __( 'Search Categories', 'maruncycore' ),
		'all_items'         => __( 'Categories', 'maruncycore' ),
		'parent_item'       => __( 'Parent Category', 'maruncycore' ),
		'parent_item_colon' => __( 'Parent Category:', 'maruncycore' ),
		'edit_item'         => __( 'Edit Category', 'maruncycore' ),
		'update_item'       => __( 'Update Category', 'maruncycore' ),
		'add_new_item'      => __( 'Add New Category', 'maruncycore' ),
		'new_item_name'     => __( 'New Category', 'maruncycore' ),
		'menu_name'         => __( 'Categories', 'maruncycore' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'project_category' ),
	);

	register_taxonomy( 'project_category', array( 'project' ), $args );
}