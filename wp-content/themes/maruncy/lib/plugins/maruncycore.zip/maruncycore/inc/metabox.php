<?php

    add_action( 'cmb2_admin_init', 'maruncy_register_post_metabox' );    
    function maruncy_register_post_metabox() {        
        $prefix = '_maruncy_';
        
        /*-- Page-Meta-Box-Fields --*/
        $maruncy_page_meta = new_cmb2_box(array(
            'id'            => $prefix . 'page_options',
            'title'         => esc_html__('Page Options', 'maruncycore' ),
            'object_types'  => array( 'page', 'service', 'project', 'team' )
        ));  
                
        $maruncy_page_meta->add_field(array(
            'name'    => esc_html__('Onepage Template:', 'maruncycore' ),
            'id'      => $prefix . 'one_page_template',
            'type'    => 'checkbox',
            'desc' => esc_html__('Will this page use as a onepage template?', 'maruncycore' )
        ));        
        $maruncy_page_meta->add_field(array(
            'name'    => esc_html__('Onepage Scroll', 'maruncycore' ),
            'id'      => $prefix . 'one_page_scroll',
            'type'    => 'checkbox',
            'desc' => esc_html__('To get a id selected scroll?', 'maruncycore' )
        ));        
        $maruncy_page_meta->add_field(array(
            'name'    => esc_html__('Remove Container', 'maruncycore' ),
            'id'      => $prefix . 'remove_page_container',
            'type'    => 'checkbox',
            'desc' => esc_html__('Remove the default page container to use elementor container.', 'maruncycore' )
        ));        
        $maruncy_page_meta->add_field(array(
            'name'    => esc_html__('Remove Page Header:', 'maruncycore' ),
            'id'      => $prefix . 'page_header',
            'type'    => 'checkbox',
            'desc' => esc_html__('Check this field if you want remove page header on this page.', 'maruncycore' )
        ));
       $maruncy_page_meta->add_field(array(
            'name'    => esc_html__('Remove Footer Area:', 'maruncycore' ),
            'id'      => $prefix . 'footer_widget',
            'type'    => 'checkbox',
            'desc' => esc_html__('Check this field if you want remove footer widgets on this page.', 'maruncycore' )
        ));
        $maruncy_page_meta->add_field( array(
            'name'    => esc_html__('Page Background Image', 'maruncycore' ),
            'desc'    => esc_html__('Upload an image or enter an URL.', 'maruncycore' ),
            'id'      => $prefix . 'page_background',
            'type'    => 'file',
            'text'    => array(
                'add_upload_file_text' => 'Add Background'
            ),
            'query_args' => array(
                 'type' => array(
                     'image/gif',
                     'image/jpeg',
                     'image/png',
                 ),
            ),
            'preview_size' => 'medium',
        ) );
    
                
        /*-- Post-Meta-Box-Content --*/
        $maruncy_post_meta = new_cmb2_box( array(
            'id'           => $prefix.'post_metabox',
            'title'        => esc_html__('Additional Fields', 'maruncycore' ),
            'object_types' => array( 'post' ), // post type
        ) );
        
        $maruncy_post_meta->add_field( array(
                'name'       => esc_html__( 'Photo Gallery',  'maruncycore'  ),
                'desc'       => esc_html__( 'This field for gallery images. This gallery show for select gallery format.',  'maruncycore'  ),
                'id'         => $prefix . 'post_gallery',
                'type'       => 'file_list',
                'text' => array(
                    'add_upload_files_text' => esc_html__('Add images', 'maruncycore' ), // default: "Add or Upload Files"
                ),
            )
        );
        
        $maruncy_post_meta->add_field( array(
            'name' => esc_html__('Embed Video', 'maruncycore' ),
            'desc' => esc_html__('Enter a youtube, twitter, or instagram URL. Supports services listed at ', 'maruncycore' ).'<a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a> '.esc_html__('This video show for select video format', 'maruncycore' ),
            'id'   => $prefix . 'post_video_embed',
            'type' => 'oembed',
        ) );
        
        $maruncy_post_meta->add_field( array(
            'name' => esc_html__('Embed Audio', 'maruncycore' ),
            'desc' => esc_html__('Enter a SoundCloud, Mixcloud, or ReverbNation etc URL. Supports services listed at ', 'maruncycore' ).'<a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a> '.esc_html__('This audio show for select audio format', 'maruncycore' ),
            'id'   => $prefix . 'post_audio_embed',
            'type' => 'oembed',
        ) );
        
        
        /*-- Post-Meta-Box-Content --*/
        $maruncy_team = new_cmb2_box( array(
            'id'           => $prefix.'team_metabox',
            'title'        => esc_html__('Team Details', 'maruncycore' ),
            'object_types' => array( 'team' ), // post type
        ) );
            
        $maruncy_team->add_field( array(
            'name' => esc_html__('Position', 'maruncycore' ),
            'id'   => $prefix . 'team_position',
            'type' => 'text_medium',
        ) );
        
        $maruncy_team->add_field( array(
            'name' => esc_html__('Facebook URL', 'maruncycore' ),
            'id'   => $prefix . 'team_facebook',
            'type' => 'text_url',
        ) );
        
        $maruncy_team->add_field( array(
            'name' => esc_html__('Twitter URL', 'maruncycore' ),
            'id'   => $prefix . 'team_twitter',
            'type' => 'text_url',
        ) );
        
        $maruncy_team->add_field( array(
            'name' => esc_html__('Linkedin URL', 'maruncycore' ),
            'id'   => $prefix . 'team_linkedin',
            'type' => 'text_url',
        ) );
        
        $maruncy_team->add_field( array(
            'name' => esc_html__('Instagram URL', 'maruncycore' ),
            'id'   => $prefix . 'team_instagram',
            'type' => 'text_url',
        ) );
        



    }
    
    if( !function_exists("maruncy_gallery_photo_list") ){
      function maruncy_gallery_photo_list( $gallery_images, $img_size = 'large' ) {
          if( empty($gallery_images) ){
              return false;
          }
            // Get the list of gallery
            $data = '<div class="photo_slider swiper-container post_media">';
            $data .= '<div class="swiper-wrapper">';
            // Loop through them and output an image
            foreach ( (array) $gallery_images[0] as $image_id => $image_url ) {
                $data .= '<div class="swiper-slide" >';
                $data .= '<div class="gallery-item" >';
                $data .= wp_get_attachment_image( $image_id, $img_size );
                $data .= '</div>';
                $data .= '</div>';
            }
            $data .= '</div>';
            $data .= '<div class="slider_arrows post_slider_arrow">';
            $data .= '<button class="slider_arrow arrow_prev"><svg class="svg_icon"> <use xlink:href="'.plugins_url( '../assets/images/symble.svg', __FILE__ ).'#arrow_left" /> </svg></button>';
            $data .= '<button class="slider_arrow arrow_next"><svg class="svg_icon"> <use xlink:href="'.plugins_url( '../assets/images/symble.svg', __FILE__ ).'#arrow_right" /> </svg></button>';
            $data .= '</div>';
            $data .= '<div class="swiper-pagination"></div>';
            $data .= '</div>';
          return $data;
        }
    }
    
    if( !function_exists('maruncy_video_embed_content') ){
        function maruncy_video_embed_content($video_url){
            if( empty($video_url) ){
                return false;
            }
            ob_start();
            ?>
            <div class="post_media video-post">
                <div class="videoPoster" style="background-image: url('<?php echo get_the_post_thumbnail_url('','full'); ?>');">
                    <button type="button" class="video-play-bttn"><i class="fa fa-play"></i></button>
                    <div class="waves-block"><div class="waves wave-1"></div><div class="waves wave-2"></div><div class="waves wave-3"></div></div>
                </div>
                <?php $get_embed = wp_oembed_get( esc_url($video_url) );
                    $get_embed = str_replace( '?','?autoplay=1&', $get_embed );
                    echo str_replace( 'src','data-src', $get_embed );
                ?>
            </div>
            <?php 
            $data = ob_get_contents();
            ob_end_clean();
            return $data;
        }
    }
    
    if( !function_exists('maruncy_audio_embed_content') ){
        function maruncy_audio_embed_content($post_audio_embed_url){
            if( empty($post_audio_embed_url) ){
                return false;
            }
            return '<div class="post_media audio-post">'.wp_oembed_get( $post_audio_embed_url ).'</div>';
        }
    }

    if(!function_exists('maruncy_admin_print_script')){
        function maruncy_admin_print_script(){
             if( get_post_type() == 'post' ): ?>
 <script type="text/javascript">
     (function($) {
         "use strict";
         $(document).on('ready', function() {
             $('.cmb2-postbox .cmb-row').css({
                 'border-bottom': 'none',
                 'margin-bottom': '0'
             });
             $('#_maruncy_post_metabox').hide(0);
             $('.cmb2-id--maruncycore-post-gallery').hide(0);
             $('.cmb2-id--maruncycore-post-video-embed').hide(0);
             $('.cmb2-id--maruncycore-post-audio-embed').hide(0);
 
             var id = $('input[name="post_format"]:checked').attr('id');
 
             if (id == 'post-format-gallery') {
                 $('#_maruncy_post_metabox').show(0);
                 $('.cmb2-id--maruncycore-post-gallery').show();
             } else {
                 $('.cmb2-id--maruncycore-post-gallery').hide();
             }
             if (id == 'post-format-video') {
                 $('#_maruncy_post_metabox').show(0);
                 $('.cmb2-id--maruncycore-post-video-embed').show();
             } else {
                 $('.cmb2-id--maruncycore-post-video-embed').hide();
             }
             if (id == 'post-format-audio') {
                 $('#_maruncy_post_metabox').show(0);
                 $('.cmb2-id--maruncycore-post-audio-embed').show();
             } else {
                 $('.cmb2-id--maruncycore-post-audio-embed').hide();
             }
             $('#post-formats-select .post-format').on('change', function() {
                 $('#_maruncy_post_metabox').hide(0);
                 $('.cmb2-id--maruncycore-post-gallery').hide(0);
                 $('.cmb2-id--maruncycore-post-video-embed').hide(0);
                 $('.cmb2-id--maruncycore-post-audio-embed').hide(0);
                 var id = $('input[name="post_format"]:checked').attr('id');
                 if (id == 'post-format-gallery') {
                     $('#_maruncy_post_metabox').show(0);
                     $('.cmb2-id--maruncycore-post-gallery').show();
                 } else {
                     $('.cmb2-id--maruncycore-post-gallery').hide();
                 }
                 if (id == 'post-format-video') {
                     $('#_maruncy_post_metabox').show(0);
                     $('.cmb2-id--maruncycore-post-video-embed').show();
                 } else {
                     $('.cmb2-id--maruncycore-post-video-embed').hide();
                 }
                 if (id == 'post-format-audio') {
                     $('#_maruncy_post_metabox').show(0);
                     $('.cmb2-id--maruncycore-post-audio-embed').show();
                 } else {
                     $('.cmb2-id--maruncycore-post-audio-embed').hide();
                 }
             });
         });
     }(jQuery));
 </script>
 <?php endif; 
        } 
     }
 add_action( 'admin_print_scripts', 'maruncy_admin_print_script',1000 );