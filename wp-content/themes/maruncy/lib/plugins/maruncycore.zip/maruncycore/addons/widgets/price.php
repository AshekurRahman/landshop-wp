<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Maruncy_Elementor_Widget_Pricing_Table extends Widget_Base {

    public function get_name() {
        return 'maruncy-pricing-table-addons';
    }
    
    public function get_title() {
        return __( 'Price Table', 'maruncycore' );
    }

    public function get_icon() {
        return 'maruncy-icon eicon-price-table';
    }
    
    public function get_categories() {
        return [ 'maruncycore' ];
    }
    
    protected function register_controls() {

    // Header Fields tab start
    $this->start_controls_section(
        'maruncy_pricing_header',
        [
            'label' => __( 'Header', 'maruncycore' ),
        ]
    );
        $this->add_control(
            'pricing_title',
            [
                'label' => __( 'Title', 'maruncycore' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'Basic Plan', 'maruncycore' ),
                'default' => __( 'Basic Plan', 'maruncycore' ),
            ]
        );
        $this->add_control(
            'pricing_sub_title',
            [
                'label' => __( 'Sub Title', 'maruncycore' ),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Enter your sub title', 'maruncycore' ),
            ]
        );
        
        $this->add_control(
            'maruncy_currency_symbol',
            [
                'label'   => __( 'Currency Symbol', 'maruncycore' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    ''             => esc_html__( 'None', 'maruncycore' ),
                    'dollar'       => '&#36; ' . __( 'Dollar', 'maruncycore' ),
                    'euro'         => '&#128; ' . __( 'Euro', 'maruncycore' ),
                    'baht'         => '&#3647; ' . __( 'Baht', 'maruncycore' ),
                    'franc'        => '&#8355; ' . __( 'Franc', 'maruncycore' ),
                    'guilder'      => '&fnof; ' . __( 'Guilder', 'maruncycore' ),
                    'krona'        => 'kr ' . __( 'Krona', 'maruncycore' ),
                    'lira'         => '&#8356; ' . __( 'Lira', 'maruncycore' ),
                    'peseta'       => '&#8359 ' . __( 'Peseta', 'maruncycore' ),
                    'peso'         => '&#8369; ' . __( 'Peso', 'maruncycore' ),
                    'pound'        => '&#163; ' . __( 'Pound Sterling', 'maruncycore' ),
                    'real'         => 'R$ ' . __( 'Real', 'maruncycore' ),
                    'ruble'        => '&#8381; ' . __( 'Ruble', 'maruncycore' ),
                    'rupee'        => '&#8360; ' . __( 'Rupee', 'maruncycore' ),
                    'indian_rupee' => '&#8377; ' . __( 'Rupee (Indian)', 'maruncycore' ),
                    'shekel'       => '&#8362; ' . __( 'Shekel', 'maruncycore' ),
                    'yen'          => '&#165; ' . __( 'Yen/Yuan', 'maruncycore' ),
                    'won'          => '&#8361; ' . __( 'Won', 'maruncycore' ),
                    'custom'       => __( 'Custom', 'maruncycore' ),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'maruncy_currency_symbol_custom',
            [
                'label'     => __( 'Custom Symbol', 'maruncycore' ),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'maruncy_currency_symbol' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'maruncy_price',
            [
                'label'   => esc_html__( 'Price', 'maruncycore' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '20',
            ]
        );

        $this->add_control(
            'maruncy_price_period',
            [
                'label'   => esc_html__( 'Period', 'maruncycore' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Per month', 'maruncycore' ),
            ]
        );
        $this->add_control(
            'maruncy_price_label',
            [
                'label'   => esc_html__( 'Label', 'maruncycore' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( '10% off for yearly subscription', 'maruncycore' ),
            ]
        );

        $this->add_control(
            'icon_type',
            [
                'label' => __('Icon Type','maruncycore'),
                'type' =>Controls_Manager::CHOOSE,
                'options' =>[
                    'img' =>[
                        'title' =>__('Image','maruncycore'),
                        'icon' =>'eicon-image-bold',
                    ],
                    'icon' =>[
                        'title' =>__('Icon','maruncycore'),
                        'icon' =>'eicon-icon-box',
                    ],
                ],
                'default' => 'icon',
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position','maruncycore'),
                'type' =>Controls_Manager::CHOOSE,
                'options' =>[
                    'position_up' =>[
                        'title' =>__('Up','maruncycore'),
                        'icon' =>'eicon-arrow-up',
                    ],
                    'position_down' =>[
                        'title' =>__('Down','maruncycore'),
                        'icon' =>'eicon-arrow-down',
                    ],
                ],
                'default' => 'position_down',
            ]
        );
        
        $this->add_control(
            'icon_image',
            [
                'label' => __('Image','maruncycore'),
                'type'=>Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'icon_type' => 'img',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'icon_imagesize',
                'default' => 'large',
                'separator' => 'none',
                'condition' => [
                    'icon_type' => 'img',
                ]
            ]
        );

        $this->add_control(
            'icon_font',
            [
                'label'       => __( 'Icon', 'maruncycore-addons' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'condition' => [
                    'icon_type' => 'icon',
                ]
            ]
        );
        
        $this->add_control(
            'connect_slider',
            [
                'label' => __( 'Connect with Range', 'maruncycore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'maruncycore' ),
                'label_off' => __( 'No', 'maruncycore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );       
                
		$this->add_control(
			'divider_number',
			[
				'label' => __( 'Divider Number', 'maruncycore' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 500,
				'step' => 1,
                'condition' => [
                    'connect_slider' => 'yes',
                ]
			]
		);
        
        $this->add_control(
             'slider_target_id',
             [
                'label'     => __( 'Enter Range Slider ID', 'maruncycore' ),
                'type'      => Controls_Manager::TEXT,
                'title' => __( 'Paste your "Range Slider Connector ID"', 'maruncycore' ),
                'condition' => [
                    'connect_slider' => 'yes',
                ]
             ]
         );


    $this->end_controls_section(); // Header Fields tab end



    // Features tab start
    $this->start_controls_section(
        'maruncy_pricing_features',
        [
            'label' => __( 'Features', 'maruncycore' ),
        ]
    );

		$repeater = new Repeater();   
            $repeater->add_control(
                'feature_icon_type',
                [
                    'label' => __('Icon Type','maruncycore'),
                    'type' =>Controls_Manager::CHOOSE,
                    'options' =>[
                        'img' =>[
                            'title' =>__('Image','maruncycore'),
                            'icon' =>'eicon-image-bold',
                        ],
                        'icon' =>[
                            'title' =>__('Icon','maruncycore'),
                            'icon' =>'eicon-icon-box',
                        ],
                    ],
                    'default' => 'icon',
                ]
            );

            $repeater->add_control(
                'feature_icon_image',
                [
                    'label' => __('Image','maruncycore'),
                    'type'=>Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'feature_icon_type' => 'img',
                    ]
                ]
            );

            $repeater->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'feature_icon_imagesize',
                    'default' => 'large',
                    'separator' => 'none',
                    'condition' => [
                        'feature_icon_type' => 'img',
                    ]
                ]
            );

            $repeater->add_control(
                'feature_icon_font',
                [
                    'label'       => __( 'Icon', 'maruncycore-addons' ),
                    'type'        => Controls_Manager::ICONS,
                    'label_block' => true,
                    'condition' => [
                        'feature_icon_type' => 'icon',
                    ]
                ]
            );
        
            $repeater->add_control(
                'feature_icon_color',
                [
                    'label'     => esc_html__( 'Icon Color', 'maruncycore' ),
                    'type'      => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .price-box {{CURRENT_ITEM}} .x-icon' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $repeater->add_control(
                'feature_text',
                [
                    'label' => __( 'Text', 'maruncycore' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Price Title', 'maruncycore' ),
                    'dynamic' => [
                        'active' => true,
                    ],
                    'label_block' => true,
                ]
            );
        
            $repeater->add_control(
                'deactive_item',
                [
                    'label' => __( 'Deactive', 'maruncycore' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Yes', 'maruncycore' ),
                    'label_off' => __( 'No', 'maruncycore' ),
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );   
        
            $this->add_control(
                'feature_items',
                [
                    'label' => __( 'Features', 'maruncycore' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'title_field' => '{{{ feature_text }}}',
                ]
            );
    $this->end_controls_section(); // Features Fields tab end


    // Footer tab start
    $this->start_controls_section(
        'maruncy_pricing_footer',
        [
            'label' => __( 'Footer', 'maruncycore' ),
        ]
    );
        
        $this->add_control(
            'maruncy_button_text',
            [
                'label'   => esc_html__( 'Button Text', 'maruncycore' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Purchase Now', 'maruncycore' ),
            ]
        );

        $this->add_control(
            'maruncy_button_link',
            [
                'label'       => __( 'Link', 'maruncycore' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => 'http://your-link.com',
                'default'     => [
                    'url' => '#',
                ],
            ]
        );
        $this->add_control(
            'pricing_footer_desc',
            [
                'label' => __( 'Description', 'maruncycore' ),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Enter your description', 'maruncycore' ),
            ]
        );
        

    $this->end_controls_section(); // Footer Fields tab end

        // price Style tab section
        $this->start_controls_section(
            'maruncy_price_style_section',
            [
                'label' => __( 'Single Card', 'maruncycore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->start_controls_tabs('price_box_style_tab');
        $this->start_controls_tab( 'price_box_normal',
            [
                'label' => __( 'Normal', 'maruncycore' ),
            ]
        );
        
        $this->add_responsive_control(
            'price_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'price_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
                
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'price_background',
                'label' => __( 'Background', 'maruncycore' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .price-box',
            ]
        );

        $this->add_responsive_control(
            'price_text_align',
            [
                'label' => __( 'Alignment', 'maruncycore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'maruncycore' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'maruncycore' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'maruncycore' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'maruncycore' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'text-align: {{VALUE}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'price_border',
                'label' => __( 'Border', 'maruncycore' ),
                'selector' => '{{WRAPPER}} .price-box',
            ]
        );
        $this->add_responsive_control(
            'price_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'price_box_shadow',
                'label' => __( 'Box Shadow', 'maruncycore' ),
                'selector' => '{{WRAPPER}} .price-box',
            ]
        );        
        $this->add_control(
            'price_box_transform',
            [
                'label' => __( 'Transform', 'maruncycore' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'translateY(0)',
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'transform: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'price_box_transition',
            [
                'label' => __( 'Transition Duration', 'maruncycore' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-box' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
        $this->end_controls_tab();             
        // Hover Style tab Start
        $this->start_controls_tab(
            'price_box_hover',
            [
                'label' => __( 'Hover', 'maruncycore' ),
            ]
        );
                
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'price_hover_background',
                'label' => __( 'Background', 'maruncycore' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .price-box:hover',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'price_border_hover',
                'label' => __( 'Border', 'maruncycore' ),
                'selector' => '{{WRAPPER}} .price-box:hover',
            ]
        );
        $this->add_responsive_control(
            'price_hover_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .price-box:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'price_box_hover_shadow',
                'label' => __( 'Box Shadow', 'maruncycore' ),
                'selector' => '{{WRAPPER}} .price-box:hover',
            ]
        );
        $this->add_control(
            'price_box_hover_transform',
            [
                'label' => __( 'Transform', 'maruncycore' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'translateY(0)',
                'selectors' => [
                    '{{WRAPPER}} .price-box:hover' => 'transform: {{VALUE}}',
                ],
            ]
        );        
        $this->end_controls_tab(); // Hover Style tab end        
        $this->end_controls_tabs();// Box Style tabs end  
    $this->end_controls_section(); // price Box section style end
        
    
    // Style tab section start
    $this->start_controls_section(
        'maruncy_price_icon_section',
        [
            'label' => __( 'Icon', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );
        $this->add_control(
            'maruncy_price_icon_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-icon' => 'color: {{VALUE}}',
                ]
            ]
        );
        $this->add_control(
            'maruncy_price_icon_size',
            [
                'label' => __( 'Font Icon Size', 'maruncycore' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_icon_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_icon_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'maruncy_price_icon_background',
                'label' => __( 'Background', 'maruncycore' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .price-box .price-icon',
            ]
        );   

    $this->end_controls_section();
    
    $this->start_controls_section(
        'maruncy_price_header_title',
        [
            'label' => __( 'Title', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'maruncy_price_title_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-title' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_title_typo',
                'selector' => '{{WRAPPER}} .price-box .price-title',
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_title_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_title_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

    $this->end_controls_section();



    $this->start_controls_section(
        'maruncy_price_header_sub_title',
        [
            'label' => __( 'Sub Title', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'maruncy_price_sub_title_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .sub-title' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_sub_title_typo',
                'selector' => '{{WRAPPER}} .price-box .sub-title',
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_sub_title_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_sub_title_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

    $this->end_controls_section();




    // Style tab section start
    $this->start_controls_section(
        'price_symble_section',
        [
            'label' => __( 'Symble', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'price_symble_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-rate .symble' => 'color: {{VALUE}}',
                ],
            ]
        );   
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'price_symble_typo',
                'selector' => '{{WRAPPER}} .price-box .price-rate .symble',
            ]
        );
        $this->add_responsive_control(
            'price_symble_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-rate .symble' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'price_symble_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-rate .symble' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
    $this->end_controls_section();
        

    // Style tab section start
    $this->start_controls_section(
        'maruncy_price_amount_section',
        [
            'label' => __( 'Amount', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );  
        $this->add_responsive_control(
            'amount_alignment',
            [
                'label' => __( 'Alignment', 'maruncycore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'justify-content: flex-start; align-items: flex-start;' => [
                        'title' => __( 'Start', 'maruncycore' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'justify-content: center; align-items: center;' => [
                        'title' => __( 'Center', 'maruncycore' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'justify-content: flex-end; align-items: flex-end;' => [
                        'title' => __( 'End', 'maruncycore' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-amount' => '{{VALUE}}',
                ],
                'separator' =>'before',
            ]
        );
       $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'pricing_amount_area_background',
                'label' => __( 'Background', 'maruncycore' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .price-box .price-amount',
            ]
        );

        $this->add_control(
            'maruncy_price_amount_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-rate' => 'color: {{VALUE}}',
                ],
            ]
        );   
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_amount_typo',
                'selector' => '{{WRAPPER}} .price-box .price-rate .amount',
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_amount_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-amount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_amount_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-amount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'button_amount_round',
            [
                'label' => esc_html__( 'Border Radius', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-amount' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
    $this->end_controls_section();

    $this->start_controls_section(
        'maruncy_price_header_preiod',
        [
            'label' => __( 'Preiod', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );
        $this->add_control(
            'maruncy_price_preiod_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .preiod' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_preiod_typo',
                'selector' => '{{WRAPPER}} .price-box .preiod',
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_preiod_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .preiod' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_preiod_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .preiod' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
    $this->end_controls_section();
        
    $this->start_controls_section(
        'maruncy_price_header_label',
        [
            'label' => __( 'Label', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );
        $this->add_control(
            'maruncy_price_label_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-label' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_label_typo',
                'selector' => '{{WRAPPER}} .price-box .price-label',
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_label_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_label_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
    $this->end_controls_section();
    
    // Features style tab start
    $this->start_controls_section(
        'maruncycore_features_style',
        [
            'label'     => __( 'Features', 'maruncycore' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
        $this->add_control(
            'pricing_features_item_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .feature-list' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'pricing_features_item_typography',
                'selector' => '{{WRAPPER}} .price-box .feature-list',
            ]
        );

        $this->add_responsive_control(
            'pricing_features_item_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .feature-list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'pricing_features_item_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .feature-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
    $this->end_controls_section(); // Features style tab end
    
    
    
    // Footer style tab start
    $this->start_controls_section(
        'maruncycore_pricing_footer_style',
        [
            'label'     => __( 'Footer', 'maruncycore' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_responsive_control(
            'pricing_footer_area_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'pricing_footer_area_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .price-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
       $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'pricing_footer_area_background',
                'label' => __( 'Background', 'maruncycore' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .price-box .price-footer',
            ]
        );
        
        $this->add_control(
            'pricing_footer_button_area',
            [
                'label'     => __( 'Button', 'maruncycore' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->start_controls_tabs( 'pricing_footer_style_tabs');

            // Pricing Normal tab start
            $this->start_controls_tab(
                'style_pricing_normal_tab',
                [
                    'label' => __( 'Normal', 'maruncycore' ),
                ]
            );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'button_background',
                        'label' => __( 'Background', 'maruncycore' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .price-box .primary_button',
                    ]
                );

                $this->add_control(
                    'button_color',
                    [
                        'label'     => __( 'Color', 'maruncycore' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button' => 'color: {{VALUE}}',
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Typography::get_type(),
                    [
                        'name'     => 'button_typography',
                        'selector' => '{{WRAPPER}} .price-box .primary_button',
                    ]
                );

                $this->add_responsive_control(
                    'button_padding',
                    [
                        'label' => __( 'Padding', 'maruncycore' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ]
                    ]
                );

                $this->add_responsive_control(
                    'button_margin',
                    [
                        'label' => __( 'Margin', 'maruncycore' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'size_units' => [ 'px', '%', 'em' ],
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Border::get_type(),
                    [
                        'name' => 'button_border',
                        'label' => __( 'Border', 'maruncycore' ),
                        'selector' => '{{WRAPPER}} .price-box .primary_button',
                    ]
                );

                $this->add_responsive_control(
                    'button_round',
                    [
                        'label' => esc_html__( 'Border Radius', 'maruncycore' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        ],
                    ]
                );

               $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'button_shadow',
                        'label' => __( 'Box Shadow', 'maruncycore' ),
                        'selector' => '{{WRAPPER}} .price-box .primary_button',
                    ]
                );

                $this->add_responsive_control(
                    'button_width',
                    [
                        'label' => __( 'Width', 'maruncycore' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                                'step' => 1,
                            ],
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button' => 'width: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );        

            $this->end_controls_tab(); // Pricing Normal tab end

            // Pricing Hover tab start
            $this->start_controls_tab(
                'style_pricing_hover_tab',
                [
                    'label' => __( 'Hover', 'maruncycore' ),
                ]
            );

                $this->add_group_control(
                    Group_Control_Background::get_type(),
                    [
                        'name' => 'pricing_footer_hover_background',
                        'label' => __( 'Background', 'maruncycore' ),
                        'types' => [ 'classic', 'gradient' ],
                        'selector' => '{{WRAPPER}} .price-box .primary_button:hover',
                    ]
                );

                $this->add_control(
                    'pricing_footer_hover_color',
                    [
                        'label'     => __( 'Color', 'maruncycore' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button:hover' => 'color: {{VALUE}}',
                        ]
                    ]
                );

                $this->add_group_control(
                    Group_Control_Border::get_type(),
                    [
                        'name' => 'pricing_footer_hover_border',
                        'label' => __( 'Border', 'maruncycore' ),
                        'selector' => '{{WRAPPER}} .price-box .primary_button:hover',
                    ]
                );

                $this->add_responsive_control(
                    'pricing_footer_hover_radius',
                    [
                        'label' => esc_html__( 'Border Radius', 'maruncycore' ),
                        'type' => Controls_Manager::DIMENSIONS,
                        'selectors' => [
                            '{{WRAPPER}} .price-box .primary_button:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                        ],
                    ]
                );

               $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'pricing_button_hover_shadow',
                        'label' => __( 'Box Shadow', 'maruncycore' ),
                        'selector' => '{{WRAPPER}} .price-box .primary_button:hover',
                    ]
                );
            $this->end_controls_tab(); // Pricing Hover tab end

        $this->end_controls_tabs();

    $this->end_controls_section(); // Footer style tab end


    $this->start_controls_section(
        'maruncy_price_header_desc_title',
        [
            'label' => __( 'Description', 'maruncycore' ),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'maruncy_price_desc_title_color',
            [
                'label'     => __( 'Color', 'maruncycore' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-box .footer-desc' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'maruncy_price_desc_title_typo',
                'selector' => '{{WRAPPER}} .price-box .footer-desc',
            ]
        );

        $this->add_responsive_control(
            'maruncy_price_desc_title_padding',
            [
                'label' => __( 'Padding', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .footer-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'maruncy_price_desc_title_margin',
            [
                'label' => __( 'Margin', 'maruncycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .price-box .footer-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );

    $this->end_controls_section();
}
private function get_currency_symbol( $symbol_name ) {
    $symbols = [
        'dollar'       => '&#36;',
        'baht'         => '&#3647;',
        'euro'         => '&#128;',
        'franc'        => '&#8355;',
        'guilder'      => '&fnof;',
        'indian_rupee' => '&#8377;',
        'krona'        => 'kr',
        'lira'         => '&#8356;',
        'peseta'       => '&#8359',
        'peso'         => '&#8369;',
        'pound'        => '&#163;',
        'real'         => 'R$',
        'ruble'        => '&#8381;',
        'rupee'        => '&#8360;',
        'shekel'       => '&#8362;',
        'won'          => '&#8361;',
        'yen'          => '&#165;',
    ];
    return isset( $symbols[ $symbol_name ] ) ? $symbols[ $symbol_name ] : '';
}

protected function render( $instance = [] ) {

    $settings   = $this->get_settings_for_display();


    $this->add_render_attribute( 'pricing_area_attr', 'class', 'price-box' );
        
    if(!empty($settings['divider_number'])){
        $this->add_render_attribute( 'pricing_area_attr', 'data-devide', $settings['divider_number'] );
    }else{
        $this->add_render_attribute( 'pricing_area_attr', 'data-devide', '0' );        
    }
    
    if(!empty($settings['slider_target_id'])){
        $this->add_render_attribute( 'pricing_area_attr', 'data-id', $settings['slider_target_id'] );
    }

    if ( ! empty( $settings['maruncy_button_link']['url'] ) ) {
        $this->add_render_attribute( 'url', 'class', 'primary_button' );
        $this->add_render_attribute( 'url', 'href', $settings['maruncy_button_link']['url'] );
        if ( $settings['maruncy_button_link']['is_external'] ) {
            $this->add_render_attribute( 'url', 'target', '_blank' );
        }
        if ( ! empty( $settings['maruncy_button_link']['nofollow'] ) ) {
            $this->add_render_attribute( 'url', 'rel', 'nofollow' );
        }
    }
    $price_rate = '';        
    if ( ! empty( $settings['maruncy_currency_symbol'] ) ) {
        if ( $settings['maruncy_currency_symbol'] != 'custom' ) {
            $price_rate .= '<span class="symble" >'.$this->get_currency_symbol( $settings['maruncy_currency_symbol'] ).'</span>';
        } else {
            $price_rate .= '<span class="symble" >'.$settings['maruncy_currency_symbol_custom'].'</span>';
        }
    }
    if ( $settings['maruncy_price'] != '' ) {
        $price_rate .= '<span class="amount">'.esc_html($settings['maruncy_price']).'</span>';
    }
    
    
    echo '<div '.$this->get_render_attribute_string( 'pricing_area_attr' ).' >';
        echo '<div class="price-header">';
            if( !empty($settings['pricing_title']) ){
                echo '<h3 class="price-title">'.esc_html( $settings['pricing_title'] ).'</h3>';
            } 
            if( !empty($settings['pricing_sub_title']) ){
                echo '<div class="sub-title">'.esc_html( $settings['pricing_sub_title'] ).'</div>';
            } 
            if($settings['icon_position'] == 'position_up'){
                if( $settings['icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_imagesize', 'icon_image' )) ){
                    $image = Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_imagesize', 'icon_image' );  
                    echo '<div class="price-icon">'.$image.'</div>';
                }elseif( $settings['icon_type'] == 'icon' && !empty($settings['icon_font']['value']) ){
                    echo sprintf( '<div class="price-icon" >%1$s</div>', maruncy_icon_manager::render_icon( $settings['icon_font'], [ 'aria-hidden' => 'true' ] ) );
                }
            }
            echo '<div class="price-amount">';
                if( !empty($price_rate) ):
                    echo '<div class="price-rate">'.wp_kses_post($price_rate).'</div>';
                endif; 
                echo '<div>';
                    if( !empty($settings['maruncy_price_period']) ):
                        echo '<h5 class="preiod">'.esc_html($settings['maruncy_price_period']).'</h5>';
                    endif;
                    if( !empty($settings['maruncy_price_label']) ):
                        echo '<div class="price-label">'.esc_html($settings['maruncy_price_label']).'</div>';
                    endif; 
                echo '</div>';
            echo '</div>';   
            if($settings['icon_position'] == 'position_down'){
                if( $settings['icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_imagesize', 'icon_image' )) ){
                    $image = Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_imagesize', 'icon_image' );  
                    echo '<div class="price-icon">'.$image.'</div>';
                }elseif( $settings['icon_type'] == 'icon' && !empty($settings['icon_font']['value']) ){
                    echo sprintf( '<div class="price-icon" >%1$s</div>', maruncy_icon_manager::render_icon( $settings['icon_font'], [ 'aria-hidden' => 'true' ] ) );
                }
            }        
        echo '</div>';
    
        if( $settings['feature_items'] ):    
            echo '<ul class="feature-list">';
                foreach ( $settings['feature_items'] as $index => $item ) :
                    echo '<li class="'.($item['deactive_item'] == 'yes' ? 'off' : 'on').' elementor-repeater-item-'.$item['_id'].'" >';
                        if( $item['feature_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $item, 'feature_icon_image', 'image' )) ){
                            $image.$index = Group_Control_Image_Size::get_attachment_image_html( $item, 'feature_icon_imagesize', 'image' );  
                            echo '<span class="price-icon">'.$image.$index.'</span>';
                        }elseif( $item['feature_icon_type'] == 'icon' && !empty($item['feature_icon_font']['value']) ){
                            echo sprintf( '<span class="x-icon" >%1$s</span>', maruncy_icon_manager::render_icon( $item['feature_icon_font'], [ 'aria-hidden' => 'true' ] ) );
                        }
                        echo wp_kses_post($this->parse_text_editor( $item['feature_text']));
                    echo '</li>';
                endforeach; 
            echo '</ul>';            
        endif;
        if( !empty($settings['maruncy_button_text']) ){
            echo '<div class="price-footer">'.sprintf( '<a %1$s>%2$s</a>', $this->get_render_attribute_string( 'url' ), $settings['maruncy_button_text'] ).'</div>';
        }
        if( !empty($settings['pricing_footer_desc']) ){
            echo '<div class="footer-desc">'.esc_html( $settings['pricing_footer_desc'] ).'</div>';
        } 
    echo '</div>';
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new Maruncy_Elementor_Widget_Pricing_Table );