<?php

namespace Codexse;

class Widgets
{
    function __construct(){
        new Widgets\PopulerPosts();

    }
}
