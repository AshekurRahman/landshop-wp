<?php
/**
 * Winners block template
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

	<p><?php _e('Please be patient. We are waiting for some orders to be paid!','wc_lottery') ?></p>

						<p><?php _e('Congratulations! You are winner!','wc_lottery') ?></p>

						<p><?php _e('Sorry, better luck next time.','wc_lottery') ?></p>
			<p><?php _e('Lottery failed because there were no participants','wc_lottery') ?></p>

			<p><?php _e('Lottery failed because there was not enough participants','wc_lottery') ?></p>



		<h3><?php _e('Winner is:','wc_lottery') ?> <?php _e('Some test user','wc_lottery') ?></h3>
